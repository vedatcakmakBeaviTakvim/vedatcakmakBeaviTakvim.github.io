@echo off
title Beavi Takvim - Kurulum
color 1F

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo HATA: Yonetici olarak calistirin!
    echo Dosyaya sag tik -- Yonetici olarak calistir
    pause
    exit
)

echo.
echo  ================================
echo    Beavi Takvim Kurulum Basliyor
echo  ================================
echo.

echo [1/4] BeaviTakvim klasoru olusturuluyor...
if not exist "C:\BeaviTakvim" mkdir "C:\BeaviTakvim"

echo [2/4] Dosyalar kopyalaniyor...
xcopy /E /I /Y "%~dp0*" "C:\BeaviTakvim\" >nul 2>&1

echo [3/4] Ayarlar olusturuluyor...
python -c "import json; f=open('C:/BeaviTakvim/takvim_ayarlar.json','w',encoding='utf-8'); f.write(json.dumps({'temel':True,'gecici_kurumlar':True,'otv':False,'bsmv':False,'dijital':False,'edefter':False,'diger':False,'sgk_isverenler':True,'elektrik_havagazi':False,'sans_oyunlari':False,'haberlesme':False,'turizm':False,'damga':False,'geri_kazanim':False,'kurumlar_ek':False})); f.close()" 2>nul

echo [4/4] Masaustu kisayolu olusturuluyor...
for /f "tokens=*" %%i in ('where pythonw 2^>nul') do set PYWPATH=%%i
if "%PYWPATH%"=="" for /f "tokens=*" %%i in ('where python 2^>nul') do set PYWPATH=%%i

powershell -Command "$ws=New-Object -ComObject WScript.Shell; $s=$ws.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Beavi Takvim.lnk'); $s.TargetPath='%PYWPATH%'; $s.Arguments='C:\BeaviTakvim\vedatbot_takvim_panel.py'; $s.WorkingDirectory='C:\BeaviTakvim'; $s.IconLocation='C:\BeaviTakvim\beavi.ico'; $s.Save()" >nul 2>&1

echo.
echo  ================================
echo    Kurulum Tamamlandi!
echo    Masaustundeki Beavi ikonuna
echo    cift tiklayin, programi acin.
echo  ================================
echo.
pause
