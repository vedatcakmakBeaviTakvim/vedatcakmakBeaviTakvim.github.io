import os, json, hashlib, uuid, datetime, sys

LISANS_DOSYA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "beavi_lisans.json")
URUN_KODU = "BEAVI2026"

def _bilgisayar_id():
    """Bilgisayara özgü benzersiz ID üret."""
    try:
        import subprocess
        result = subprocess.check_output(
            "wmic csproduct get uuid", shell=True, stderr=subprocess.DEVNULL
        ).decode().strip().split("\n")
        for r in result:
            r = r.strip()
            if r and r != "UUID" and len(r) > 10:
                return r
    except Exception:
        pass
    try:
        return str(uuid.getnode())
    except Exception:
        return "FALLBACK"

def _hash(veri):
    return hashlib.sha256(veri.encode()).hexdigest()[:16].upper()

def anahtar_dogrula(anahtar):
    """Anahtarı doğrula. Geçerliyse (True, gun_kalan) döner."""
    anahtar = anahtar.strip().upper().replace(" ", "-")
    parca = anahtar.split("-")
    if len(parca) != 4 or parca[0] != "BEAVI":
        return False, 0

    bilgisayar = _bilgisayar_id()
    gun_kodu = parca[1]       # YYMM formatında
    imza = parca[2]
    kontrol = parca[3]

    # Kontrol hash
    beklenen = _hash(URUN_KODU + gun_kodu + imza + bilgisayar[:8])[:4]
    if kontrol != beklenen:
        # Evrensel anahtar kontrolü (bilgisayar bağımsız — demo/test için)
        beklenen2 = _hash(URUN_KODU + gun_kodu + imza + "UNIVERSAL")[:4]
        if kontrol != beklenen2:
            return False, 0

    # Süre kontrolü
    try:
        yil = 2000 + int(gun_kodu[:2])
        ay = int(gun_kodu[2:])
        bitis = datetime.datetime(yil, ay, 1) + datetime.timedelta(days=395)
        kalan = (bitis - datetime.datetime.now()).days
        if kalan < 0:
            return False, 0
        return True, kalan
    except Exception:
        return False, 0

def lisans_kaydet(anahtar, gun_kalan):
    bilgisayar = _bilgisayar_id()
    veri = {
        "anahtar": anahtar.upper(),
        "bilgisayar": _hash(bilgisayar),
        "kurulum": datetime.datetime.now().isoformat(),
        "gun_kalan": gun_kalan
    }
    with open(LISANS_DOSYA, "w", encoding="utf-8") as f:
        json.dump(veri, f, ensure_ascii=False, indent=2)

def lisans_kontrol():
    """
    Kayıtlı lisansı kontrol et.
    Döner: ("gecerli", gun_kalan) | ("suresi_doldu", 0) | ("yok", 0)
    """
    if not os.path.exists(LISANS_DOSYA):
        return "yok", 0
    try:
        with open(LISANS_DOSYA, "r", encoding="utf-8") as f:
            veri = json.load(f)
        anahtar = veri.get("anahtar", "")
        bilgisayar = _bilgisayar_id()
        if veri.get("bilgisayar") != _hash(bilgisayar):
            return "yok", 0
        gecerli, gun_kalan = anahtar_dogrula(anahtar)
        if gecerli:
            return "gecerli", gun_kalan
        return "suresi_doldu", 0
    except Exception:
        return "yok", 0
