@echo off
cd /d C:\vedatbootClaud\Beavi
start /min "" pythonw vedatbot_takvim_panel.py
